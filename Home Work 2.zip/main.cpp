#include <iostream>
#include "answer.h"

//hour
//minute
//country

int main() {
    //1
    std::cout<<"#1\n\n";
    Time time1(0,0),time2,time3;
    time1.setHour(5),time1.setMinute(54),time1.setCountry("Iran");
    std::cout<<"in "<<time1.getCountry() << " time is:\t"<< time1.getHour() << ":" << time1.getMinute() <<  std::endl;
    time1.print_time();

    std::cout<<"----------------------------------\n#2\n\n";
    //2
    time2.setCountry("Germany");
    time2.print_time();
    time2.add_hour();
    time2.add_minute();
    time2.print_time();
    time2.add_time(time1);
    time2.print_time();
    time2.add_hour(35);
    time2.print_time();
    time2.add_minute(78);
    time2.print_time();

    std::cout<<"----------------------------------\n#3\n\n";
    //3

    time3.setCountry("Spain");
    time3=time2;
    time3.print_time();
    std::cout<< (time3==time2) << std::endl; //doesnt include country
    std::cout<< (time3<time2) << std::endl;
    std::cout<< (time3>time2) << std::endl;
    std::cout<< (time1<=time2) << std::endl;
    std::cout<< (time3>=time2) << std::endl;
    std::cout<< (time3!=time2) << std::endl;
    std::cout<< (time3<"10:54") << std::endl;
    std::cout<< (time3>"2:35") << std::endl;
    !time3;
    time3.print_time();
    std::cout<<++time3;
    std::cout<<time3++;
    std::cout<<time3;

    std::cout<<"----------------------------------\n#4\n\n";
    //4

    Time time4(4,34,"England");
    std::cout<< (time4+time3);
    std::cout<< (time4.operator+("2:13"));
    std::cout<<time4;
    time4+=time3;
    std::cout<<time4;
    time4+="2:1";
    std::cout<<time4;
    std::cout<<"in "<<time4.getCountry() << " time is:\t"<< time4[0] << ":" << time4[1] <<  std::endl;
    std::cout<<"in "<<time4.getCountry() << " time is:\t"<< time4["hour"] << ":" << time4["minute"] <<  std::endl;
    std::cout<<"remember this\t"<<time4[30] << " and this\t"<<time4["else"]<<std::endl;//anything but 0,1,hour,minute

    std::cout<<"----------------------------------\n#5\n\n";
    //5

    Time time5;
    std::cin>>time5;
    std::cout<<time5;
    //*= true
    //=* false
    time5= *time4(1,2);
    std::cout<<time4<<time5;
    time5= *time4("10:54");
    std::cout<<time4<<time5;
    std::cout<< std::endl<<(time5 + "1:2");
    std::cout<< ("3:4" + time5)<<std::endl; //bonus

    std::cout<<"----------------------------------\n#final\n\n";
    //final
    std::cout<<time1<<time2<<time3<<time4<<time5;

    return 0;
}
